-- AlterTable
ALTER TABLE "UserProfile" ADD COLUMN     "elo" TEXT;
